@@UninstallOracleWebEvents.sql
@@UninstallOracleSiteMap.sql
@@UninstallOracleRoles.sql
@@UninstallOracleProfile.sql
@@UninstallOraclePersonalization.sql
@@UninstallOracleMembership.sql
@@UninstallOracleASPNETCommon.sql
@@UninstallOracleSessionState.sql
